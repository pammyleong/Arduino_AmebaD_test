#ifndef _ALEXA_HTTP2_SERVICE_H_
#define _ALEXA_HTTP2_SERVICE_H_

#include <inttypes.h>

uint8_t alexa_upload_state();

void init_alexa_http2_service();

#endif