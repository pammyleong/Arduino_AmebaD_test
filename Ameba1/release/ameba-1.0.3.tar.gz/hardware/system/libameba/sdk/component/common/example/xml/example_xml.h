#ifndef EXAMPLE_XML_H
#define EXAMPLE_XML_H

void example_xml(void);

#endif /* EXAMPLE_XML_H */
