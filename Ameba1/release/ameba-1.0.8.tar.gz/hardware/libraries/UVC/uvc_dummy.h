#ifndef _UVC_DUMMY_H_
#define _UVC_DUMMY_H_
#endif