#ifndef EXAMPLE_UVC_H
#define EXAMPLE_UVC_H

#include <platform/platform_stdlib.h>
#include "platform_opts.h"
#include "dlist.h"
#include "osdep_api.h"

#define UVC_RTSP_EN     1

void example_uvc(void);

#endif /* EXAMPLE_UVC_H */