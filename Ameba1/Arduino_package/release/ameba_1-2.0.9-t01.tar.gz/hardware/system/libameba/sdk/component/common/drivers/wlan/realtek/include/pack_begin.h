
/*
  *    Copyright(c) 2007 - 2011 Realtek Corporation. All rights reserved.
  *
  * 	Define the start point of packed structure
  *
  */
 

#if defined(__IAR_SYSTEMS_ICC__)
#pragma pack(1)
#endif

#if defined(PLATFORM_WINDOWS)
#pragma pack(push)
#pragma pack(1)
#endif

