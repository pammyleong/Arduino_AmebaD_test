#ifndef	_TIME_64_GCC_H
#define _TIME_64_GCC_H

#define __time_t_defined
#define time_t long long

#endif //_TIME_64_GCC_H