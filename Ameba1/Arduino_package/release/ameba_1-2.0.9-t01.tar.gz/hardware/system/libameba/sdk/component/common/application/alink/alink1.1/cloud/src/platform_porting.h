#ifndef __PLATFORM_PORTING__
#define __PLATFORM_PORTING__

#ifndef _PLATFORM_AMEBA__
#define _PLATFORM_AMEBA__
#endif
/*
#define WSF_WORKER_THREAD_STACKSIZE 0x1500
#define ALINK_MAIN_THREAD_STACKSIZE 0xc00
#define CALLBACK_WORKER_STACKSIZE 0x800
#define SEND_WORKER_STACKSIZE 0x800
#define ALINK_OTA_THREAD_STACKSIZE 0xc00
*/

/*******************************FreeRTOS**********************************/
/*								_PLATFORM_CUSTOMER_										*/
/**********************************************************************************/
#if defined(_PLATFORM_AMEBA__)

#include "platform_stdlib.h"
#include "alink_export.h"
#include "aws_platform.h"
#include "lwip/def.h"

#if defined(CONFIG_PLATFORM_8711B)	
#include "rtl8710b_ota.h"
#endif
//include h file here.
//#include "porting_ameba.h"

/******************************************************
 *                    Macros
 ******************************************************/

#if defined(CONFIG_PLATFORM_8711B)
//#define SDK_SOFTVER    "rtl-sdk-v3.6-svn19181"
//#define MODULE_TYPE    "RTL8710BN"
//#define ALINK_COMPILE_TIME "2016/12/06-11:37:53" 
#else
#ifndef OFFSET_DATA
#define OFFSET_DATA		FLASH_SYSTEM_DATA_ADDR
#endif
#ifndef IMAGE_2
#define IMAGE_2			0x0000B000
#endif

#ifdef CONFIG_CUSTOM_SIGNATURE
#undef CONFIG_CUSTOM_SIGNATURE
#define CONFIG_CUSTOM_SIGNATURE		1
#else
#define CONFIG_CUSTOM_SIGNATURE		1
#endif
//#define SDK_SOFTVER    "rtl-sdk-v3.5-svn21077"
//#define MODULE_TYPE    "RTL8711AM"
//#define ALINK_COMPILE_TIME "2017/03/13-19:46:45" 
#endif

extern char sdk_softver[32];
extern char module_type[32];
extern char alink_compile_time[32];

//porting:pthread_cond_t,pthread_mutex_t,pthread_t
typedef void* pthread_cond_t;       /* identify a condition variable */
typedef void* pthread_mutex_t;      /* identify a mutex */
typedef void* pthread_t;            /* identify a thread */

#define SSID_LEN_MAX     32
#define WIFIKEY_LEN_MAX 32

#ifndef bool
#define bool int
#endif

#ifndef true
#define true 1
#endif

#ifndef false
#define false 0
#endif

#ifndef int64_t
#define int64_t   signed long long
#endif
#ifndef uint64_t
#define uint64_t  unsigned long long
#endif
#ifndef uint8
#define uint8 unsigned char
#endif
#ifndef uint16
#define uint16 unsigned short
#endif
#ifndef uint32
#define uint32 unsigned int
#endif
#ifndef int8
#define int8 char
#endif
#ifndef int16
#define int16 short
#endif
#ifndef int32
#define int32 int
#endif

#ifdef lwip_ntohs
u16_t lwip_ntohs(u16_t x);
#endif /* lwip_ntohs */

#ifdef lwip_ntohl
u32_t lwip_ntohl(u32_t n);
#endif /* lwip_ntohs */

typedef struct sockaddr_in alink_sockaddr_t;
typedef struct sockaddr alink_sockaddr;
typedef u32_t in_addr_t;

typedef void (*thread_callback)(void *);


#define ALINK_THREAD_PTR(th) (th)
#define ALINK_THREAD_IS_VALID(th) th
#define ALINK_THREAD_RESET(th) \
do { \
} while (0)

typedef struct timeval alink_timeval_t;
//#define isdigit(c) (((c) >= '0') && ((c) <= '9'))
//#define srand(a)

#define TX_WAIT_FOREVER         0	//sys_arch_sem_wait(a,TX_WAIT_FOREVER)
//#define ULONG unsigned long

#define pthread_mutex_lock(a)    sys_mutex_lock(a)//        tx_mutex_get(a, TX_WAIT_FOREVER)
#define pthread_mutex_unlock(a)  sys_mutex_unlock(a)    
#define pthread_mutex_init(a, b) sys_mutex_new(a)
#define pthread_mutex_destroy(a) sys_mutex_free(a)
#define pthread_cond_init(a, b)  sys_sem_new(a,0) 
#define pthread_cond_destroy(a)  sys_sem_free(a)
#define pthread_cond_signal(a)	 sys_sem_signal(a) 

#define pthread_join(a, b)       \
do { \
} while(0)

#define pthread_cancel(a)    \
do { \
} while(0)   

#define SHA256_CTX                 sha256_context
#define MD5_CTX                 md5_context
#endif //_PLATFORM_AMEBA__

u16 alink_get_tcp_new_port();
int alink_load_wifi_config();
int alink_rand();
void *ssl_connect(int fd, int cert_len, const char *cert, int *err);
int ssl_force_close(void *ssl);
int ssl_pending(void *ssl);
int ssl_recv(void *ssl, void *buf, int length);
int ssl_send(void *ssl, const char *ptr, int length);
int pthread_cond_wait(pthread_cond_t *cond, pthread_mutex_t *mutex);
int alink_pthread_cond_timedwait(pthread_cond_t * cond,	 pthread_mutex_t * mutex, int timeout);
int create_thread(pthread_t *thread, const char *thread_name, void *callback, void *arg, int stack_size);
void alink_exit_thread(void *threadId);
int alink_is_current_thread(pthread_t *threadId);
alink_sockaddr_t *alink_create_addr(struct sockaddr_in *addr, in_addr_t ip, short port);
void wait_network_up();
void SocketClose(int *fd);
void alink_sleep(int millsec);
int resolve_ip(const char *addr, in_addr_t * ip);
int alink_create_socket(int domain, int type, int protocol);
char *alink_get_addr_string(alink_sockaddr_t *addr, char *ip_port_buff, unsigned int buff_size);
int alink_valid_socket(int sock);
//�ַ�����ʽip��ַת����������4Byte ip��ַ
uint32_t alink_inet_addr(const char *ip_addr);
//������4Byte ip��ַת�����ַ�����ʽip��ַ
char *alink_inet_ntoa(uint32_t ip_addr, char *ip_str, unsigned int buff_size);
int alink_setsockopt(int socket, int level, int optname, const void *optval, socklen_t optlen);
void alink_keepalive_enable(int socket, int onoff, int idle, int intvl, int cnt);

int alink_md5_init(void *ctx);
int alink_md5_update(void *ctx, unsigned char *input, int ilen);
int alink_md5_final(void *ctx, unsigned char output[16]);
int alink_sha256_init(void *ctx);
int alink_sha256_update(void *ctx, const void *data,	unsigned long len);
int alink_sha256_final(unsigned char *res, void *ctx);
unsigned int alink_get_os_time_sec();
int alink_get_wifi_station_rssi();
int alink_get_free_heap_size();
int alink_recv(int socket, char *buf, int len, int flag);
int alink_send(int socket, char *buf, int len, int flags);
int alink_printf_free_mem();
void alink_os_reboot();
int alink_get_vender_sdk_version(char * buffer,unsigned int len);
void alink_create_mreq_opt(struct ip_mreq *mreq, unsigned int group_addr, unsigned int interface_addr);
int ota_firmware_save( char *buffer, int len);
int ota_upgrade(void);
char* alink_get_module_name(char * buffer,unsigned int len);
unsigned int  platform_thread_get_stack_size(const char *thread_name);

#define xos_print(SW, MOD, LVL, FMT, ...)\
do{\
    if (SW){\
        printf("<%s/%s> [%s#%d]: " FMT "\r\n", MOD, LVL, __FUNCTION__, __LINE__, ##__VA_ARGS__);\
    }\
} while(0)
extern int global_alink_loglevel;

#define wsf_fatal(FMT, ...) \
    xos_print(global_alink_loglevel & ALINK_LL_FATAL, "ALINK", "FATAL", FMT, ##__VA_ARGS__)
#define wsf_err(FMT, ...) \
    xos_print(global_alink_loglevel & ALINK_LL_ERROR, "ALINK", "ERROR", FMT, ##__VA_ARGS__)
#define wsf_warn(FMT, ...) \
    xos_print(global_alink_loglevel & ALINK_LL_WARN, "ALINK", "WARN", FMT, ##__VA_ARGS__)
#define wsf_log(FMT, ...) \
    xos_print(global_alink_loglevel & ALINK_LL_INFO, "ALINK", "INFO", FMT, ##__VA_ARGS__)
#define wsf_dump(FMT, ...) \
    xos_print(global_alink_loglevel & ALINK_LL_DUMP, "ALINK", "DUMP", FMT, ##__VA_ARGS__)
#define wsf_deb(FMT, ...) \
    xos_print(global_alink_loglevel & ALINK_LL_DEBUG, "ALINK", "DEBUG", FMT, ##__VA_ARGS__)
#define wsf_trace(FMT, ...) \
    xos_print(global_alink_loglevel & ALINK_LL_TRACE, "ALINK", "TRACE", FMT, ##__VA_ARGS__)

#define ALINK_ERROR		0
#define ALINK_WARNING	1
#define ALINK_INFO		2
#define ALINK_DEBUG		3
#define ALINK_NONE		0xFF
#define ALINK_DEBUG_LEVEL ALINK_INFO

#if (ALINK_DEBUG_LEVEL == ALINK_NONE)
#define alink_printf(level, fmt, arg...)
#else
#define alink_printf(level, fmt, arg...)     \
do {\
	if (level <= ALINK_DEBUG_LEVEL) {\
		if (level <= ALINK_ERROR) {\
			printf("\r\nERROR: " fmt, ##arg);\
		} \
		else {\
			printf("\r\n"fmt, ##arg);\
		} \
	}\
}while(0)
#endif

#undef alink_err_printf
#define alink_err_printf(fmt, args...) \
	     	rtl_printf("%s(): " fmt "\n", __FUNCTION__, ##args); 

#endif				//end of __PLATFORM_PORTING__
