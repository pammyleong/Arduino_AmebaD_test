/*
 * airkiss_porting.h
 *
 *  Created on: Dec 16, 2015
 *      Author: zorrowu
 */

#ifndef AIRKISS_PORTING_H_
#define AIRKISS_PORTING_H_

#include "airkiss_types.h"

typedef enum {
	AK_TCP_CONNECT_SUCCESS		= 0,		//succeed
	AK_TCP_CONNECT_FAILED		= -1,		//failed
	AK_TCP_CONNECT_WAITING		= 2,		//waiting
} airkiss_tcp_state;

typedef enum {
	AK_DNS_SUCCESS		= 0,		//succeed
	AK_DNS_FAILED		= -1,		//failed
	AK_DNS_WAITING		= 2,		//waiting
} airkiss_dns_state;

#define AIRKISS_ENABLE_LOG				
#define AIRKISS_SUPPORT_MULTITHREAD	

/*** App log print ***/
#define WX_ERROR		0
#define WX_WARNING	1
#define WX_INFO		2
#define WX_DEBUG		3
#define WX_NONE		0xFF

#define WX_DEBUG_LEVEL WX_DEBUG

#if (WX_DEBUG_LEVEL >= WX_NONE)
#define wx_printf(level, fmt, arg...)
#else
#define wx_printf(level, fmt, arg...)     \
do {\
	if (level <= WX_DEBUG_LEVEL) {\
	switch(level)\
	{\
	case WX_ERROR :\
		printf("\r\n[Error] "fmt, ##arg);\
		break;\
	case WX_WARNING :\
		printf("\r\n[Warning] "fmt, ##arg);\
		break;\
	case WX_INFO :\
		printf("\r\n[Info] "fmt, ##arg);\
		break;\
	case WX_DEBUG :\
		printf("\r\n[Debug] "fmt, ##arg);\
		break;\
	default :\
		printf("\r\n[Level] "fmt, ##arg);\
		break;\
	}\
	}\
}while(0)
#endif
/******/

// SDK log print
#ifdef AIRKISS_ENABLE_LOG
int airkiss_printfImp(const char *fmt, ...);
#endif

#ifdef AIRKISS_SUPPORT_MULTITHREAD
int airkiss_mutex_create(ak_mutex_t *mutex_ptr);
int airkiss_mutex_lock(ak_mutex_t *mutex_ptr);
int airkiss_mutex_unlock(ak_mutex_t *mutex_ptr);
int airkiss_mutex_delete(ak_mutex_t *mutex_ptr);
#endif

int airkiss_dns_gethost(char* url, uint32_t* ipaddr);
int airkiss_dns_checkstate(uint32_t* ipaddr);

ak_socket airkiss_tcp_socket_create();
int airkiss_tcp_connect(ak_socket sock, char* ipaddr, uint16_t port);
int airkiss_tcp_checkstate(ak_socket sock);
int airkiss_tcp_send(ak_socket socket, char*buf, uint32_t len);
void airkiss_tcp_disconnect(ak_socket socket);
int airkiss_tcp_recv(ak_socket socket, char *buf, uint32_t size, uint32_t timeout);


uint32_t airkiss_gettime_ms();
int32_t airkiss_msleep(uint32_t milliseconds);


// @return   status: Success:1 or Failure: Others.
int  device_flash_stream_read(uint32_t address, uint32_t len, uint8_t * data);

// @return   status: Success:1 or Failure: Others.
int  device_flash_read_word(uint32_t address, uint32_t * data);

// @return   status: Success:1 or Failure: Others.
int  device_flash_stream_write(uint32_t address, uint32_t len, uint8_t * data);

// @return   status: Success:1 or Failure: Others.
int  device_flash_write_word(uint32_t address, uint32_t data);

// @return   none.
void  device_flash_erase_sector(uint32_t address);

//void* airkiss_malloc(uint32_t size);
//void airkiss_free(void *p);
//void *airkiss_calloc(uint32_t n, uint32_t size);
#endif /* AIRKISS_PORTING_H_ */
