#ifndef _AWS_PLATFORM_H_
#define _AWS_PLATFORM_H_

#include "platform_stdlib.h"

/*softAP mode code*/
#ifdef __cplusplus
extern "C" {
#endif

/*NETMASK*/
#ifndef ALINK_NETMASK_ADDR0
#define ALINK_NETMASK_ADDR0   255
#define ALINK_NETMASK_ADDR1   255
#define ALINK_NETMASK_ADDR2   255
#define ALINK_NETMASK_ADDR3   0
#endif

/*Gateway Address*/
#ifndef ALINK_GW_ADDR0
#define ALINK_GW_ADDR0   172
#define ALINK_GW_ADDR1   31
#define ALINK_GW_ADDR2   254
#define ALINK_GW_ADDR3   250
#endif

/* DHCP Assigned Starting Address*/
#ifndef ALINK_DHCP_START_ADDR0  
#define ALINK_DHCP_START_ADDR0   172
#define ALINK_DHCP_START_ADDR1   31
#define ALINK_DHCP_START_ADDR2   254
#define ALINK_DHCP_START_ADDR3   240  
#endif

/* DHCP Assigned Ending Address*/
#ifndef ALINK_DHCP_END_ADDR0   
#define ALINK_DHCP_END_ADDR0   172
#define ALINK_DHCP_END_ADDR1   31
#define ALINK_DHCP_END_ADDR2   254
#define ALINK_DHCP_END_ADDR3   255  
#endif

#ifndef WLAN0_NAME
  #define WLAN0_NAME		"wlan0"
#endif
#ifndef WLAN1_NAME
  #define WLAN1_NAME		"wlan1"
#endif

#ifndef int64_t
#define int64_t   signed long long
#endif
#ifndef uint64_t
#define uint64_t  unsigned long long
#endif
#ifndef uint8
#define uint8 unsigned char
#endif
#ifndef uint16
#define uint16 unsigned short
#endif
#ifndef uint32
#define uint32 unsigned int
#endif
#ifndef int8
#define int8 char
#endif
#ifndef int16
#define int16 short
#endif
#ifndef int32
#define int32 int
#endif

/*For Alink Defined SoftAP*/
#define AP_NAME             "alink_light"
#define AP_PASSWORD         "123456789"

#define SOFTAP_GATEWAY_IP          ((u32)0xFAFE1FAC)
#define SOFTAP_TCP_SERVER_PORT          (65125)

//#define LOGLEVEL_NONE		0
#define LOGLEVEL_ERROR		0
#define LOGLEVEL_WARN		1
#define LOGLEVEL_INFO		2
#define LOGLEVEL_DEBUG		3
#define LOGLEVEL_NONE		0xFF

#define AWS_DEBUG_LEVEL LOGLEVEL_INFO
#if (AWS_DEBUG_LEVEL== LOGLEVEL_NONE)
#define aws_printf(level, fmt, arg...)
#else
#define aws_printf(level, fmt, arg...)     \
do {\
	if (level <= LOGLEVEL_DEBUG) {\
		if (level <= LOGLEVEL_ERROR) {\
			printf("\r\nERROR: " fmt, ##arg);\
		} \
		else {\
			printf("\r\n"fmt, ##arg);\
		} \
	}\
}while(0)
#endif

#undef aws_err_printf
#define aws_err_printf(fmt, args...) \
	     	rtl_printf("%s(): " fmt "\n", __FUNCTION__, ##args); 

/* Parsed Information Elements */
struct i802_11_elems {
	const u8 *ie;
	u8 len;
};

#define MANAGMENT_FRAME_FILTER_TEST	0

/*
 * platform porting API
 */

//一键配置超时时间, 建议超时时间1-3min, APP侧一键配置1min超时
extern int aws_timeout_period_ms;
extern int softap_timeout_period_ms;

//一键配置每个信道停留时间, 建议200ms-400ms
extern int aws_chn_scanning_period_ms;

//系统自boot起来后的时间, 用于判断收包之间的间隔时间
unsigned int vendor_get_time_ms(void);

//aws库会调用该函数用于信道切换之间的sleep
void vendor_msleep(int ms);

//系统malloc/free函数
void *vendor_malloc(int size);
void vendor_free(void *ptr);

//系统打印函数, 可不实现
void vendor_printf(int log_level, const char* log_tag, const char* file,
	const char* fun, int line, const char* fmt, ...);

//product model/secret, i.e.
//model		"ALINKTEST_LIVING_LIGHT_SMARTLED"
//secret	"YJJZjytOCXDhtQqip4EjWbhR95zTgI92RVjzjyZF"
char *vendor_get_model(void);
char *vendor_get_secret(void);
//wifi mac string, format xx:xx:xx:xx:xx:xx
//Note: return NULL if product is registered by sn
char *vendor_get_mac(void);
//product sn string
//Note: return NULL if product is registered by mac
char *vendor_get_sn(void);
//return alink version
//return value:
//10 -- alink 1.0
//11 -- alink 1.1
//20 -- alink 2.0
int vendor_alink_version(void);

//aws库调用该函数来接收80211无线包
//若平台上通过注册回调函数aws_recv_80211_frame()来收包时，
//将该函数填为vendor_msleep(100)
int vendor_recv_80211_frame(void);

//进入monitor模式, 并做好一些准备工作，如
//设置wifi工作在默认信道6
//若是linux平台，初始化socket句柄，绑定网卡，准备收包
//若是rtos的平台，注册收包回调函数aws_recv_80211_frame()到系统接口
void vendor_monitor_open(void);

//退出monitor模式，回到station模式, 其他资源回收
void vendor_monitor_close(void);

//wifi信道切换，信道1-13
void vendor_channel_switch(char primary_channel,char secondary_channel,
		char bssid[6]);

//通过以下函数发送配网成功通知给APP, 端口定义如下
#define UDP_TX_PORT			(65123)
#define UDP_RX_PORT			(65126)
int vendor_broadcast_notification(char *msg, int msg_num);

int8 rtl_get_mac_address( uint8* szmac );

void rtl_var_init();

void rtl_restore_wifi_info_to_flash();

/*return---- 0:succese, -1: fail*/
int rtl_softAP_start(const int8* ap_name, const int8 *ap_password);

//SOFTAP: setup softap tcp server
int rtl_create_tcp_server();

int rtl_connect_ap(unsigned char *ssid, unsigned char *passwd);

int auth_trans(char encry);

#ifndef WPA_GET_BE24(a)
#define WPA_GET_BE24(a) ((((u32) (a)[0]) << 16) | (((u32) (a)[1]) << 8) | \
			 ((u32) (a)[2]))
#endif
int wifi_enable_managment_frame_filter(int enable_or_disable);
int wifi_send_raw_packaget (uint8 *buf, uint16 len, bool sys_seq);
int wifi_set_management_frame_fileter(u8 *oui, u8 oui_type, u8 frame_type, int (*callback)(const u8 *ie, char *ie_len, int frame_type));
#if MANAGMENT_FRAME_FILTER_TEST
int wifi_build_mgnt_frame(int type);
#endif

#endif
