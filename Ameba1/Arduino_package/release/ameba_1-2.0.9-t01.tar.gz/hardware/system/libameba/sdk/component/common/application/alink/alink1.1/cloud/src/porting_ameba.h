#include "FreeRTOS.h"
#include "basic_types.h"
#include "task.h"
#include "diag.h"
#include "lwip/api.h"
#include "lwip/inet.h"
#include "sockets.h"
#include "polarssl/config.h"
#include "polarssl/ssl.h"
#include "alink_md5.h"
#include "sha256.h"
//#include "atcmd_wifi.h"
//#include "log_service.h"
#include <lwip_netconf.h>
#include <wifi/wifi_conf.h>

#if defined(CONFIG_PLATFORM_8195A)
#define _PLATFORM_AMEBA__
#endif
typedef u32_t in_addr_t;
#define SHA256_CTX sha256_context