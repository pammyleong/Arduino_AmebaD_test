
/*
 * All rights reserved.
 */
#ifndef WX_EXTERN_H_
#define WX_EXTERN_H_

#include "airkiss_types.h"
#include "airkiss_cloudapi.h"

/************* MACRO ****************/
#define APP_THREAD_STACK_SIZE			(1024)		// unit : 4Byte
#define CLOUD_THREAD_STACK_SIZE		(1024)		// unit : 4Byte
#define CLOUD_THREAD_HEAP_SIZE		(1024 * 2)	// unit : 4Byte
#define CLOUD_NOTIFY_THREAD_STACK_SIZE	(1024)		// unit : 4Byte
#define CLOUD_WDG_TIMEOUT 			((20)*(1000))	//airkiss_cloud_device_watchdog timeout,in ms

void reg_callback_fun(airkiss_callbacks_t *pcbs);

#endif
