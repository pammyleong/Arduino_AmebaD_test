
#ifndef AIRKISS_CLOUD_WIFI_H_
#define AIRKISS_CLOUD_WIFI_H_

#include "airkiss_types.h"
#include "airkiss_porting.h"

void
airkiss_cloud_write_wifi_info(void);
int
airkiss_cloud_read_wifi_info(void);
void
airkiss_disconnect_handler(char *buf, int buf_len, int flags, void* handler_user_data );

#endif
