/*
 * how_to_build_library_for_aliOS
 */
 
1. Modify Macro
	1）change macro "PLATFORM_ALIOS" to "#define PLATFORM_ALIOS 1" in platform_autoconf.h
	2）change “#define printf rtl_printf” to “#define printf DiagPrintf” in line 202 of platform_stdlib.h

2. Build libraries
   Enter component\common\application\alios to make 

3. After make, libraries can be found in "component\common\application\alios\lib_all"


modify log：
2019-7-30	remove no-short-enums；
2019-10-17	change toolchains from 4_8-2014q3 to 7-2018-q2