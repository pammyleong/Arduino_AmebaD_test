#ifndef _MESH_DATA_DUMP_H_
#define _MESH_DATA_DUMP_H_

#include <stdint.h>

void mesh_data_dump(uint8_t *pbuffer, uint32_t len);

#endif //_MESH_DATA_DUMP_H_

