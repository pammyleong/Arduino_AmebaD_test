#ifndef __ATCMD_FTL_H__
#define __ATCMD_FTL_H__
void at_ftl_init(void);

#endif
