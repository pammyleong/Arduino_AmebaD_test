#ifndef DUERAPP_USER_DEFINE_H
#define DUERAPP_USER_DEFINE_H

void duer_control_point_init();
#endif