# Hello!
We are an open source project of [ARM mbed](www.mbed.com). Contributions via [pull request](https://github.com/armmbed/mbed-client-trace/pulls), and [bug reports](https://github.com/armmbed/mbed-client-trace/issues) are welcome!

For more details please see our general [CONTRIBUTING.md](https://github.com/ARMmbed/greentea/blob/master/docs/CONTRIBUTING.md) document.

# Contributor agreement
For your pull request to be accepted, we will need you to agree to our [contributor agreement](http://developer.mbed.org/contributor_agreement/) to give us the necessary rights to use and distribute your contributions. (To click through the agreement create an account on mbed.com and log in.)

<3
