in ir_led document, ir is used to generate specific WS2812C-2020 waveforms needed by LED.
in led application, carrier frequency should be set more than 10MHz