#ifndef _MODELCONFIG_H
#define _MODELCONFIG_H

#define MASTER_CLOCK    48054857  // Master Clock
#define USART0_BAUDRATE 115200    // USART Baudrate

#endif // _MODELCONFIG_H
