#ifndef PLATFORM_STDLIB_STM32_H
#define PLATFORM_STDLIB_STM32_H
  
  #include <stdio.h>
  #include <stdlib.h>
  #include <string.h>
  #include <stdint.h>
  
#endif // PLATFORM_STDLIB_STM32_H
